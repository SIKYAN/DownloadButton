/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./DownloadButton/index.ts":
/*!*********************************!*\
  !*** ./DownloadButton/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.DownloadButton = void 0;\n\nvar DownloadButton =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function DownloadButton() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  DownloadButton.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _this = this; // Add control initialization code\n\n\n    this._context = context;\n    this._container = container;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._btn01 = document.createElement('button');\n    this._a = document.createElement('a');\n    this._btn01.innerHTML = \"Download!!\";\n\n    this._container.appendChild(this._btn01);\n\n    this._container.appendChild(this._a);\n\n    this._btn01.addEventListener('click', function () {\n      _this._a.click();\n    });\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  DownloadButton.prototype.updateView = function (context) {\n    var _b; // Add code to update control view\n\n\n    var dataUri = ((_b = this._context.parameters.fileContent.raw) === null || _b === void 0 ? void 0 : _b.startsWith('data:')) ? this._context.parameters.fileContent.raw : \"data:\".concat(this._context.parameters.fileMIMEType.raw, \";base64,\").concat(this._context.parameters.fileContent.raw);\n    console.log(dataUri);\n    this._a.href = dataUri;\n    this._a.download = this._context.parameters.fileName.raw || \"\";\n    var testvar = 'test';\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  DownloadButton.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  DownloadButton.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return DownloadButton;\n}();\n\nexports.DownloadButton = DownloadButton;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DownloadButton/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./DownloadButton/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SikControl.DownloadButton', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DownloadButton);
} else {
	var SikControl = SikControl || {};
	SikControl.DownloadButton = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DownloadButton;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}